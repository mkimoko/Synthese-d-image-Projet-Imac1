#ifndef SDL_TOOLS_H_
#define SDL_TOOLS_H_

#include <SDL/SDL.h>

void PutPixel(SDL_Surface* surface, int x, int y, Uint32 pixel);

#endif
